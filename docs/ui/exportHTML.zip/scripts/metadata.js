define(function(){
    return {
        pageGroups: [{"id":"ddad823a-2783-09f0-7cff-b4d87cde291d","name":"Default group","pages":[{"id":"87885693-7f7c-5452-ce65-9fba8cad8d0b","name":"Page 1"}]},{"id":"84b714dd-6ad4-ab60-9065-e2ef235d3a5c","name":"Default group","pages":[{"id":"b137a89b-0335-0559-a971-f8813a5c9388","name":"Page 1"},{"id":"d01676f4-271d-2585-3aa9-1e28f25c0727","name":"Page 2"},{"id":"85f311a3-ee8f-dc12-31a3-876995980ba4","name":"Page 3"},{"id":"d7b27230-044f-8211-4c28-379837103a2a","name":"Copy of Page 2"},{"id":"282c77c3-50ba-b3a8-4d05-0d7674e8b6da","name":"Copy of Copy of Page 2"},{"id":"2b9083fa-07a4-4a71-7566-0d5bf6761eb0","name":"Copy of Copy of Copy of Page 2"},{"id":"9998b4f2-e664-4902-8daa-d9f3edcd803a","name":"Copy of Page 3"}]}],
        downloadLink: "//services.ninjamock.com/html/htmlExport/download?shareCode=72VCJ&projectName=Untitled project",
        startupPageId: 0,

        forEachPage: function(func, thisArg){
        	for (var i = 0, l = this.pageGroups.length; i < l; ++i){
                var group = this.pageGroups[i];
                for (var j = 0, k = group.pages.length; j < k; ++j){
                    var page = group.pages[j];
                    if (func.call(thisArg, page) === false){
                    	return;
                    }
                }
            }
        },
        findPageById: function(pageId){
        	var result;
        	this.forEachPage(function(page){
        		if (page.id === pageId){
        			result = page;
        			return false;
        		}
        	});
        	return result;
        }
    }
});
